package com.spotify.sdk.demo;

public class MusicTrack {
}
