//Problem when search for song betwqeen 90 and 100

package com.spotify.sdk.demo.activity;

import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;
import com.spotify.android.appremote.demo.R;
import com.spotify.protocol.client.ErrorCallback;
import com.spotify.sdk.demo.DataImporter;
import com.spotify.sdk.demo.MyDB;
import com.spotify.sdk.demo.MyHelper;
import com.spotify.sdk.demo.MyMainViewPagerAdapter;
import com.spotify.sdk.demo.MyRVAdapter;
import com.spotify.sdk.demo.RecyclerViewClickInterface;
import com.spotify.sdk.demo.fragments.PlaylistFragment;
import com.spotify.sdk.demo.activity.RemotePlayerActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.appcompat.widget.AppCompatSeekBar;
import androidx.appcompat.widget.AppCompatTextView;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.spotify.android.appremote.api.SpotifyAppRemote;
import com.spotify.android.appremote.demo.R;
import com.spotify.protocol.client.Subscription;
import com.spotify.protocol.types.Capabilities;
import com.spotify.protocol.types.CrossfadeState;
import com.spotify.protocol.types.PlayerContext;
import com.spotify.protocol.types.PlayerState;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;

import androidx.fragment.app.FragmentActivity;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.appcompat.widget.AppCompatSeekBar;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.appcompat.widget.PopupMenu;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.spotify.android.appremote.api.ConnectionParams;
import com.spotify.android.appremote.api.Connector;
import com.spotify.android.appremote.api.ContentApi;
import com.spotify.android.appremote.api.SpotifyAppRemote;
import com.spotify.android.appremote.demo.R;
import com.spotify.protocol.client.ErrorCallback;
import com.spotify.protocol.client.Subscription;
import com.spotify.protocol.types.Capabilities;
import com.spotify.protocol.types.Image;
import com.spotify.protocol.types.ListItem;
import com.spotify.protocol.types.PlaybackSpeed;
import com.spotify.protocol.types.PlayerContext;
import com.spotify.protocol.types.PlayerState;
import com.spotify.protocol.types.Repeat;
import com.spotify.protocol.types.CrossfadeState;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, SensorEventListener, AdapterView.OnItemClickListener, RecyclerViewClickInterface, SeekBar.OnSeekBarChangeListener {

    private final String TAG = "I AM A PIRATE AAAAAAAA";
    private final ErrorCallback mErrorCallback = this::logError;
    MyDB db;
    MyHelper helper;

    RecyclerView myRV;
    RecyclerViewClickInterface myRVInterface;

    private boolean isSongQueueExpanded = false;

    private AlertDialog.Builder dialogBuilder;
    private AlertDialog dialog;
    private EditText runningModeHintET;

    SeekBar manualBpmSeekbar;
    ArrayList<ArrayList<String>> filteredBPMList;

    private int currentBPM;


//////////////////////////////////////////////////////////CAMERAAAAAAAAAAAAAA

    ImageButton cameraButton;
    ImageView cameraImage;

    Button shareButton;

    Bitmap photo = null;

    TextView reminderText;

    private int REQUEST_CODE_PERMISSIONS = 101;

    private static final int REQUEST_EXTERNAL_STORAGE_RESULT = 1;
    private final String[] REQUIRED_PERMISSIONS = new String[]{"android.permission.CAMERA"};

    Subscription<PlayerState> mPlayerStateSubscription;
    Subscription<PlayerContext> mPlayerContextSubscription;
    Subscription<Capabilities> mCapabilitiesSubscription;


    File pictureDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "CameraDemo");
    private Uri fileUri;

///////////////////////////////////////////////////////////CAMERAAAAAAAAAAAAAA

    TabLayout tabLayout;
    ViewPager2 viewPager2;
    MyMainViewPagerAdapter myViewPagerAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        db = new MyDB(this);
        helper = new MyHelper(this);


        //        if(db==null) {


//        }
        manualBpmSeekbar = findViewById(R.id.bpmSeekBar);

        manualBpmSeekbar.setOnSeekBarChangeListener(this);

        MyRVAdapter myRVAdapter = new MyRVAdapter(DataImporter.list, this, this);
        myRV = findViewById(R.id.runPlaylistRV);
        myRV.setLayoutManager(new LinearLayoutManager(this));
        myRV.setHasFixedSize(true);

        myRV.setAdapter(new MyRVAdapter(DataImporter.list, this, this));
        Log.e("DATAIMPORTER_LIST", DataImporter.list.toString());
        myRV.setOnClickListener(this);
        myRVInterface = this;
        myRVAdapter.notifyDataSetChanged();
        filteredBPMList = DataImporter.list;

        onSubscribedToPlayerStateButtonClicked(null);

        TextView scrollingText = (TextView)findViewById(R.id.smallplayerSongNameTV);
        scrollingText.setSelected(true);

        Log.i("DB_CHECK", db.getAllData().toString());


        //CAMERAAAAAA
        cameraButton = (ImageButton) findViewById(R.id.cameraButton);
//        cameraButton.setOnClickListener(this);
//
//        cameraImage = (ImageView) findViewById(R.id.cameraImage);
//
//        shareButton = (Button) findViewById(R.id.shareButton);
//
//        reminderText = (TextView) findViewById(R.id.reminderTextView);

///////////////////////////////////////////////////////////////////////REDACTED FRAGMENTS
//        tabLayout = findViewById(R.id.main_tab_layout);
//        viewPager2=findViewById(R.id.main_view_pager);
//        myViewPagerAdapter=new MyMainViewPagerAdapter(this);
//        viewPager2.setAdapter(myViewPagerAdapter);
//        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
//            @Override
//            public void onTabSelected(TabLayout.Tab tab) {
//                viewPager2.setCurrentItem(tab.getPosition());
//            }
//            @Override
//            public void onTabUnselected(TabLayout.Tab tab) {
//
//            }
//            @Override
//            public void onTabReselected(TabLayout.Tab tab) {
//
//            }
//        });
//        viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
//            @Override
//            public void onPageSelected(int position) {
//                super.onPageSelected(position);
//                tabLayout.getTabAt(position).select();
//            }
//        });
// /////////////////////////////////////////////////////////////////////REDACTED FRAGMENTS
        (((RadioButton)findViewById(R.id.runningModeAutoButton))).setOnClickListener(this);
        (((RadioButton)findViewById(R.id.runningModeManualButton))).setOnClickListener(this);

    }

    ///////////////////////////////////////////////////////////////////CAMERAAAAAAAAAA
    ///////////////////////////////////////////////////////////////////////REDACTED FRAGMENTS
//    private void replaceFragment(PlaylistFragment playlistFragment) {
//
//        FragmentManager fragmentManager = getSupportFragmentManager();
//        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
//        fragmentTransaction.replace(R.id.main_view_pager,playlistFragment);
//        fragmentTransaction.commit();
//
//    }
    ///////////////////////////////////////////////////////////////////////REDACTED FRAGMENTS


    public void onRecyclerItemClick(int position) {
        Log.i("DB_CHECK", db.getAllData().toString());
        Log.i("DB_CHECK", db.getSelectedData(position).toString());
//        Log.i("RECYCLER_CLICK",filteredBPMList.toString());
        String selectedSongName = filteredBPMList.get(position).get(2);
        Log.i("DB_CHECK", selectedSongName);
        Log.i("DB_CHECK", db.getSelectedData(selectedSongName).get(1).toString());
        playUri(db.getSelectedData(selectedSongName).get(1));

    }

    //COPIED METHODS
    //COPIED METHODS
    //COPIED METHODS
    //COPIED METHODS
    //VVVVVVVV

    private void playUri(String uri) {
        RemotePlayerActivity.mSpotifyAppRemote
                .getPlayerApi()
                .play(uri)
                .setResultCallback(empty -> logMessage(getString(R.string.command_feedback, "play")))
                .setErrorCallback(mErrorCallback);
    }

    private void logMessage(String msg) {
        logMessage(msg, Toast.LENGTH_SHORT);
    }

    private void logMessage(String msg, int duration) {
        Toast.makeText(this, msg, duration).show();
        Log.d(TAG, msg);
    }

    private void logError(Throwable throwable) {
        Toast.makeText(this, R.string.err_generic_toast, Toast.LENGTH_SHORT).show();
        Log.e(TAG, "", throwable);
    }


    @Override
    public void onClick(View view) {
        if(view == cameraButton) {
            if (allPermissionsGranted()) {
                Intent camera_intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                resultLauncher.launch(camera_intent);
            } else {
                ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS);
            }
        }


        if((view == (((RadioButton)findViewById(R.id.runningModeAutoButton)))) || (view ==((RadioButton)findViewById(R.id.runningModeManualButton))))
        {
            if(((RadioButton)findViewById(R.id.runningModeManualButton)).isChecked()){
                ((TextView)findViewById(R.id.speedHeaderTV)).setText("Set speed");
                ((SeekBar)findViewById(R.id.bpmSeekBar)).setClickable(true);
                ((SeekBar)findViewById(R.id.bpmSeekBar)).setFocusable(true);
                ((SeekBar)findViewById(R.id.bpmSeekBar)).setThumbTintList(ColorStateList.valueOf(Color.GREEN));
                ((SeekBar)findViewById(R.id.bpmSeekBar)).setProgressTintList(ColorStateList.valueOf(Color.GREEN));

            }
            else if (((RadioButton)findViewById(R.id.runningModeAutoButton)).isChecked()){
                ((TextView)findViewById(R.id.speedHeaderTV)).setText("Current speed");
                ((SeekBar)findViewById(R.id.bpmSeekBar)).setFocusable(false);
                ((SeekBar)findViewById(R.id.bpmSeekBar)).setClickable(false);
                ((SeekBar)findViewById(R.id.bpmSeekBar)).setThumbTintList(ColorStateList.valueOf(Color.DKGRAY));
                ((SeekBar)findViewById(R.id.bpmSeekBar)).setProgressTintList(ColorStateList.valueOf(Color.DKGRAY));

            }
            Log.i("RUNNING_MODE", String.valueOf(((RadioButton)findViewById(R.id.runningModeAutoButton)).isChecked()));
            Log.i("RUNNING_MODE", String.valueOf(((RadioButton)findViewById(R.id.runningModeManualButton)).isChecked()));
        }
    }

    public void onBackPressed() {
        moveTaskToBack(true);
    }

    public void onClickSeekToChorus(View view) {
        Log.i("CHORUS_CHECK_4", "CHORUS_CHECK_4");
        Log.i("CHORUS_CHECK_4", (long) RemotePlayerActivity.chorusTime + "");
        RemotePlayerActivity.mSpotifyAppRemote
                .getPlayerApi().seekTo((long) RemotePlayerActivity.chorusTime * 1000);

    }


    ///////////////////////////////////////////////////////////////////CAMERAAAAAAAAAA
    ActivityResultLauncher<Intent> resultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    photo = (Bitmap) result.getData().getExtras().get("data");

                    cameraImage.setImageBitmap(photo);
                }
            });

    private boolean allPermissionsGranted() {
        for (String permission : REQUIRED_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(getApplicationContext(), permission) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (allPermissionsGranted()) {
            Intent camera_intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            resultLauncher.launch(camera_intent);
        } else {
            Toast.makeText(this, "Permissions not granted by the user.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    public void shareActivities(View view) {
        shareImage(photo);
    }

    private void shareImage(Bitmap photo) {

        if (photo == null) {

            reminderText.setVisibility(View.VISIBLE);

        } else {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("image/jpeg");
            Uri bitmapUri;

            //        String textToShare = "abc";

            bitmapUri = saveImage(photo, getApplicationContext());
            share.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            share.putExtra(Intent.EXTRA_STREAM, bitmapUri);
            //        share.putExtra(Intent.EXTRA_SUBJECT, "cde");
            //        share.putExtra(Intent.EXTRA_TEXT, textToShare);

            share.setClipData(ClipData.newRawUri("", bitmapUri));
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

            startActivity(Intent.createChooser(share, "Share Image"));
        }

    }

    private static Uri saveImage(Bitmap image, Context context) {
        File imageFile = new File(context.getCacheDir(), "images");
        Uri uri = null;

        try {
            imageFile.mkdir();
            File file = new File(imageFile, "shared_images.jpg");

            FileOutputStream stream = new FileOutputStream(file);
            image.compress(Bitmap.CompressFormat.JPEG, 90, stream);

            stream.flush();
            stream.close();

            uri = FileProvider.getUriForFile(Objects.requireNonNull(context.getApplicationContext()), "com.spotify.android.appremote.demo" + ".provider", file);

        } catch (IOException error) {
            Log.d("Exception", error.getMessage());
        }
        return uri;
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
//        Sensor sensor = sensorEvent.sensor;
//        if (sensor.getType() == Sensor.TYPE_STEP_COUNTER)
//        {
//            stepCount = (int) sensorEvent.values[0];
//
//            stepCounter.setText(String.valueOf(stepCount));
//        }
//        else if (sensor.getType() == Sensor.TYPE_STEP_DETECTOR)
//        {
//            stepDetect = (int) (stepDetect + sensorEvent.values[0]);
//
//            stepDetector.setText(String.valueOf(stepDetect));
//
//
//        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        try {
            String bpmComment = "";
            currentBPM = seekBar.getProgress() * 10 + 30;
            bpmComment = getBPMComment(currentBPM);

            ((TextView) findViewById(R.id.bpmSeekbarValueTV)).setText(currentBPM + " - " + (currentBPM + 10) + " ("+  bpmComment  + ")");
            Log.i("RUN_FRAGMENT", "yeah that's good");
            filteredBPMList = db.getSelectedDataTempoRange(currentBPM, (float) (currentBPM + 9.9999));
            Log.i("FILTERED_BPM_CHECK", filteredBPMList.toString());
            MyRVAdapter myRVAdapter = new MyRVAdapter(filteredBPMList, this, this);
            myRV = findViewById(R.id.runPlaylistRV);
            myRV.setLayoutManager(new LinearLayoutManager(this));
            myRV.setHasFixedSize(true);
            myRV.setAdapter(new MyRVAdapter(filteredBPMList, this, this));
            Log.e("LIST", DataImporter.list.toString());
            myRV.setOnClickListener(this);
            myRVAdapter.notifyDataSetChanged();
        } catch (Exception e) {
            Log.e("RUN_FRAGMENT", "U STOOPID");
        }


    }

    private String getBPMComment(int currentBPM){
        String bpmComment ="";
        if(currentBPM < 60){
            bpmComment = "Tutel";
        }
        else if( 60 <= currentBPM && currentBPM < 80 )
        {
            bpmComment = "Strolling";
        }
        else if( 80 <= currentBPM && currentBPM < 110 )
        {
            bpmComment = "Walking";
        }
        else if( 110 <= currentBPM && currentBPM < 130 )
        {
            bpmComment = "Brisk Walk";
        }
        else if( 130 <= currentBPM && currentBPM < 150 )
        {
            bpmComment = "Jogging";
        }
        else if( 150 <= currentBPM && currentBPM < 170 )
        {
            bpmComment = "Running";
        }
        else if( 170 <= currentBPM && currentBPM < 210 )
        {
            bpmComment = "Sprinting";
        }
        else if( 210 <= currentBPM && currentBPM < 230 )
        {
            bpmComment = "Running for your life";
        }
        else
        {
            bpmComment = "Cheeto";
        }
        return bpmComment;
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
    //share image code study from: https://www.youtube.com/watch?v=BWZv0iynWkE

    public void OnClickSwitchToPlayerIntent(View view) {
        startActivity(new Intent(this, MyRemotePlayerActivity.class));
    }

    public void onPlayPauseButtonClicked(View view) {
        RemotePlayerActivity.mSpotifyAppRemote
                .getPlayerApi()
                .getPlayerState()
                .setResultCallback(
                        playerState -> {
                            if (playerState.isPaused) {
                                RemotePlayerActivity.mSpotifyAppRemote
                                        .getPlayerApi()
                                        .resume()
                                        .setResultCallback(
                                                empty -> logMessage(getString(R.string.command_feedback, "play")))
                                        .setErrorCallback(mErrorCallback);
                            } else {
                                RemotePlayerActivity.mSpotifyAppRemote
                                        .getPlayerApi()
                                        .pause()
                                        .setResultCallback(
                                                empty -> logMessage(getString(R.string.command_feedback, "pause")))
                                        .setErrorCallback(mErrorCallback);
                            }
                        });
    }

    ///////////////////////////////////////////////////////////////////CAMERAAAAAAAAAA END
    ///////////////////////////////////////////////////////////////////SPOTITY START
    private final Subscription.EventCallback<PlayerState> mPlayerStateEventCallback =
            new Subscription.EventCallback<PlayerState>() {
                @Override
                public void onEvent(PlayerState playerState) {
                    if (playerState.track != null) {
                        ((TextView) findViewById(R.id.smallplayerSongNameTV)).setText(playerState.track.name);
                        ((TextView) findViewById(R.id.smallplayerSongArtistTV)).setText(playerState.track.artist.name);
                        RemotePlayerActivity.mSpotifyAppRemote
                                .getImagesApi()
                                .getImage(playerState.track.imageUri, Image.Dimension.LARGE)
                                .setResultCallback(
                                        bitmap -> {
                                            ((ImageView)findViewById(R.id.smallplayerSongArtIV)).setImageBitmap(bitmap);

                                        });
                    }
                    if (playerState.isPaused) {
                        ((ImageButton)findViewById(R.id.smallplayerPlayPauseButton)).setImageResource(R.drawable.btn_play);
                    } else {
                        ((ImageButton)findViewById(R.id.smallplayerPlayPauseButton)).setImageResource(R.drawable.btn_pause);
                    }
                }
            };


    public void onSubscribedToPlayerStateButtonClicked(View view) {

        if (mPlayerStateSubscription != null && !mPlayerStateSubscription.isCanceled()) {
            mPlayerStateSubscription.cancel();
            mPlayerStateSubscription = null;
        }

        mPlayerStateSubscription =
                (Subscription<PlayerState>)
                        RemotePlayerActivity.mSpotifyAppRemote
                                .getPlayerApi()
                                .subscribeToPlayerState()
                                .setEventCallback(mPlayerStateEventCallback)
                                .setLifecycleCallback(
                                        new Subscription.LifecycleCallback() {
                                            @Override
                                            public void onStart() {
                                                logMessage("Event: start");
                                            }

                                            @Override
                                            public void onStop() {
                                                logMessage("Event: end");
                                            }
                                        })
                                .setErrorCallback(
                                        throwable -> {

                                        });
    }

    public void onClickShowRunningModeHint(View view){
        dialogBuilder = new AlertDialog.Builder(this);
        final View runningModeHintPopup = getLayoutInflater().inflate(R.layout.running_mode_popup,null);

        dialogBuilder.setView(runningModeHintPopup);
        dialog = dialogBuilder.create();
        dialog.show();


    }

    public void onClickToggleSongQueueSize(View view){
        if(isSongQueueExpanded == true) {
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    0,
                    0.1f
            );
            ((LinearLayout) findViewById(R.id.SongQueueLL)).setLayoutParams(params);
            Log.i("TOGGLE_QUEUE", "Shrink queue");

            ((LinearLayout) findViewById(R.id.runPlaylistRVLL)).setLayoutParams( new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    0,
                    0));

            ((LinearLayout) findViewById(R.id.mainActivityHeaderLL)).setLayoutParams( new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    0,
                    0.1f));
            Log.i("TOGGLE_QUEUE", "Expand");

            isSongQueueExpanded = false;

        }
        else{
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    0,
                    0.7f
            );
            ((LinearLayout) findViewById(R.id.SongQueueLL)).setLayoutParams(params);
            Log.i("TOGGLE_QUEUE", "Expand");


            ((LinearLayout) findViewById(R.id.runPlaylistRVLL)).setLayoutParams( new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    0,
                    6f));
            Log.i("TOGGLE_QUEUE", "Expand");

            ((LinearLayout) findViewById(R.id.mainActivityHeaderLL)).setLayoutParams( new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    0,
                    0.1f));
            Log.i("TOGGLE_QUEUE", "Expand");


            isSongQueueExpanded = true;
        }
    }

}



