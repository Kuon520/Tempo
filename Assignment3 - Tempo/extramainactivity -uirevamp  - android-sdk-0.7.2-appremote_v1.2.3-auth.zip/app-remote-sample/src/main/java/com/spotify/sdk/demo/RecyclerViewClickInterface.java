package com.spotify.sdk.demo;

public interface RecyclerViewClickInterface {
    void onRecyclerItemClick(int position);
}
